import './sample.scss';

console.log('sample.js');
