<?php
/**
 * Plugin Name: Five by Five
 * Plugin URI: https://www.fivebyfive.com.au/
 * Description: Five by Five
 * Version: 1.0
 * Author: Five by Five
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 */

define('FF_MODULES_DIR', WP_PLUGIN_DIR.'/fivebyfive_modules/');

include 'init.php';
