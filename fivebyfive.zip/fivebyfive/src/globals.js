import Hooks from 'js/hooks';

export const global_hooks = new Hooks([]);
